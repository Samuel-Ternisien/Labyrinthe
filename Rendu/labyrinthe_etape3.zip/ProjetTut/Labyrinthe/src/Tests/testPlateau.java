package Tests;

import Composants.Piece;
import Composants.PieceM0;
import Composants.Plateau;
import Composants.Utils;
import grafix.interfaceGraphique.IG;

public class testPlateau {
    public static void main(String[] args) {
        Plateau platTest  = new Plateau();
        platTest.placerPiecesAleatoirment();

    }
}
