# Projet Tutoré du S2
## Groupe composé de

- Ternisien Samuel
- Bobe Baptiste
- Bouque Antoine
- Louchart Antoine
- Tuteur : Mme. Coste 
